#include <SDL2/SDL.h>
#include <SDL_image.h>
#include <SDL_ttf.h>
#include <SDL_mixer.h>
#include <string>
#include <cmath>
#include <iomanip>
#include <iostream>

int sdl_quit() {
	SDL_Window* window = nullptr;
    SDL_Renderer* renderer = nullptr;
    SDL_Texture* image = nullptr;
    SDL_Texture* textTexture = nullptr;
    TTF_Font* font = nullptr;
    SDL_Surface* surface = nullptr;
    Mix_Chunk* buttonSound = nullptr;
	
	SDL_StopTextInput();
	SDL_FreeSurface(surface);
	SDL_DestroyTexture(textTexture);
	TTF_CloseFont(font);
	SDL_DestroyTexture(image);
    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);
    Mix_FreeChunk(buttonSound);
	Mix_CloseAudio();
    TTF_Quit();
    SDL_Quit();
    IMG_Quit();
    std::cout << "👋 Closing projectILE. Have a good day!\n";
    return 0;
}

int main() {
	std::cout << "⚙️ projectILE by Primiçerius Software @2025\n";
	//SDL INIT
	SDL_Init(SDL_INIT_VIDEO | SDL_INIT_AUDIO);
    IMG_Init(IMG_INIT_PNG | IMG_INIT_JPG);
    TTF_Init();
    
    if (Mix_OpenAudio(44100, MIX_DEFAULT_FORMAT, 2, 2048) < 0) {
		std::cout << "❌ SDL2 Can't initialize the audio, please contact developers.\n";
        std::cerr << "❌ SDL_INIT_AUDIO_ERROR : " << Mix_GetError() << "\n";
        return 1;
    }
    
    std::cout << "✅ All modules initialized successfully.\n";
	
	//ERROR HANDLING
    if (SDL_Init(SDL_INIT_VIDEO) < 0) {
		std::cout << "❌ SDL2 Can't initialize the video, please contact developers.\n";
        std::cerr << "❌ SDL_INIT_VIDEO_ERROR : " << SDL_GetError() << "\n";
        return 1;
    }
   
	//WINDOW
    SDL_Window* window = SDL_CreateWindow(
        "projectILE BETA V1.0",
        SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED,
        1000, 1000,
        SDL_WINDOW_SHOWN
    );
    std::cout << "✅ The window created successfully.\n";
    
    if (!window) {
		std::cout << "❌ SDL2 Can't create the window, please contact developers.\n";
        std::cerr << "❌ SDL_WINDOW_ERROR: " << SDL_GetError() << "\n";
        return 1;
    }
    
	//WINDOW RENDER
    SDL_Renderer* renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);
    
    //SOUND LOAD
    Mix_Chunk* buttonSound = Mix_LoadWAV("button.wav");
	if (!buttonSound) {
		std::cerr << "Failed to load sound: " << Mix_GetError() << std::endl;
	}

    //FONT LOAD
	TTF_Font* font = TTF_OpenFont("unageo.ttf", 25);
	if (!font) {
		std::cout << "❌ SDL2 Can't load the font\n";
		std::cout << "⁉️ Did you delete or change the name of 'unageo.ttf' file?\n";
		std::cerr << "❌ SDL_FONT_LOAD_ERROR: " <<	TTF_GetError() << "\n";
		return 1;
	}
	std::cout << "✅ Font loaded successfully.\n";
	
    //IMAGE LOAD
    
    //MENU IMAGES
    SDL_Texture* ILE_logo = IMG_LoadTexture(renderer, "textures/projectile_logo.png");
    SDL_Texture* change_e_variable_button = IMG_LoadTexture(renderer, "textures/change_e_variable_button.png");
    SDL_Texture* exit_button = IMG_LoadTexture(renderer, "textures/exit_button.png");
    SDL_Texture* launch_angle_calc_button = IMG_LoadTexture(renderer, "textures/launch_angle_calc_button.png");
    SDL_Texture* ashot_arrow = IMG_LoadTexture(renderer, "textures/ashot_arrow.png");
    SDL_Texture* ashot_rocket = IMG_LoadTexture(renderer, "textures/ashot_rocket.png");
    SDL_Texture* info_button = IMG_LoadTexture(renderer, "textures/info_button.png");
    
    //CALCULATOR IMAGES
    SDL_Texture* main_menu = IMG_LoadTexture(renderer, "textures/main_menu.png");
    SDL_Texture* info = IMG_LoadTexture(renderer, "textures/info.png");
    SDL_Texture* enter_button = IMG_LoadTexture(renderer, "textures/enter.png");
    SDL_Texture* warning = IMG_LoadTexture(renderer, "textures/warning.png");
    SDL_Texture* warning1 = IMG_LoadTexture(renderer, "textures/warning1.png");
    SDL_Texture* calculatee = IMG_LoadTexture(renderer, "textures/calculate.png");
    SDL_Texture* ew = IMG_LoadTexture(renderer, "textures/ew.png");
    SDL_Texture* et = IMG_LoadTexture(renderer, "textures/et.png");
    SDL_Texture* emv = IMG_LoadTexture(renderer, "textures/emv.png");
    SDL_Texture* ehfta = IMG_LoadTexture(renderer, "textures/ehfta.png");
    SDL_Texture* e_launch_angle = IMG_LoadTexture(renderer, "textures/enter_l_angle.png");
    SDL_Texture* c_air_pressure = IMG_LoadTexture(renderer, "textures/c_air_pressure.png");
    SDL_Texture* c_air_temperature = IMG_LoadTexture(renderer, "textures/c_air_temperature.png");
    SDL_Texture* c_error_tolerance = IMG_LoadTexture(renderer, "textures/c_error_tolerance.png");
	
	//image size
	int W250, H150;
	int W50, H50;
	int W100, H100;
	int W500, H300;
	int W200, H120;
	int Wlogo, Hlogo;
	SDL_QueryTexture(change_e_variable_button, nullptr, nullptr, &W250, &H150);
	SDL_QueryTexture(info_button, nullptr, nullptr, &W50, &H50);
	SDL_QueryTexture(main_menu, nullptr, nullptr, &W100, &H100);
	SDL_QueryTexture(info, nullptr, nullptr, &W500, &H300);
	SDL_QueryTexture(ew, nullptr, nullptr, &W200, &H120);
	SDL_QueryTexture(warning, nullptr, nullptr, &W500, &H100);
	SDL_QueryTexture(warning1, nullptr, nullptr, &W500, &H100);
	SDL_QueryTexture(ILE_logo, nullptr, nullptr, &Wlogo, &Hlogo);
	
	//image rect
	SDL_Rect menu_button_1_rect = {675, 110, W250, H150};
	SDL_Rect menu_button_2_rect = {675, 285, W250, H150};
	SDL_Rect menu_button_3_rect = {675, 460, W250, H150};
	SDL_Rect menu_button_4_rect = {675, 635, W250, H150};
	SDL_Rect menu_button_5_rect = {675, 810, W250, H150};
	SDL_Rect menu_button_6_rect = {620, 425, W50, H50};
	SDL_Rect buttonRect7 = {895, 895, W100, H100};
	SDL_Rect buttonRect14 = {360, 725, W100, H100};
	SDL_Rect enter_button_1_rect = {445, 635, W100, H100};
	SDL_Rect info_rect = {90, 310, W500, H300};
	SDL_Rect buttonRect9 = {75, 700, W250, H150};
	SDL_Rect buttonRect10 = {100, 100, W200, H120};
	SDL_Rect buttonRect11 = {100, 250, W200, H120};
	SDL_Rect buttonRect12 = {100, 400, W200, H120};
	SDL_Rect buttonRect13 = {100, 550, W200, H120};
	SDL_Rect buttonRect15 = {465, 725, W500, H100};
	SDL_Rect cairp_button_rect = {675, 460, W250, H150};
	SDL_Rect cairt_button_rect = {375, 460, W250, H150};
	SDL_Rect cerrort_button_rect = {75, 460, W250, H150};
	SDL_Rect ILE_logo_rect = {23, 30, Wlogo, Hlogo};
	
	std::cout << "✅ Images loaded/initialized successfully\n";
	
	double air_pressure = 101325;
	double temp_celcius = 15.0;
	double error_tolerance = 0.5;
	
	//MAIN LOOP VARIABLES
    bool running = true;
    bool show_info = false;
    bool typing = false;
    bool calculate = false;
    std::string screens = "MAIN_MENU";
    
    //CALCULATION VARIABLES
    std::string inputText;
    double error_handler = 0.0;
    double best_error_low = 9e9;
	double best_error_high = 9e9;
	double best_angle_low = 0.0;
	double best_angle_high = 0.0;
    double writing_variable = 0.0;
    double velocity = 0.0;
    double target = 0.0;
    double diameter = 0.0;
    double mass = 0.0;
    double launch_angle = 0.0;
    double landing_pos = 0.0;
    double max_height_reach = 0.0;
    double total_time = 0.0;
    double* current_variable = nullptr;
    SDL_Event event;
    
    std::cout << "✅ Variables created/initialized successfully\n";
    
    //FONT RENDER TEST
	SDL_Color textColor_black = {0, 0, 0};
	//SDL_Color textColor_white = {255, 255, 255};
	int textW = 0, textH = 0;
	
    SDL_Surface* menu_text_surf1 = TTF_RenderText_Blended(font, "projectILE by Primicerius Software @2025", textColor_black);
    SDL_Texture* menu_text_txt1 = SDL_CreateTextureFromSurface(renderer, menu_text_surf1);
    SDL_FreeSurface(menu_text_surf1);
    SDL_QueryTexture(menu_text_txt1, NULL, NULL, &textW, &textH);
    SDL_Rect menu_text_rect1 = {5, 965, textW, textH};
    
    SDL_Surface* menu_text_surf2 = TTF_RenderText_Blended(font, "projectILE BETA V1.0 - 'GUI UPDATE'", textColor_black);
    SDL_Texture* menu_text_txt2 = SDL_CreateTextureFromSurface(renderer, menu_text_surf2);
    SDL_FreeSurface(menu_text_surf2);
    SDL_QueryTexture(menu_text_txt2, NULL, NULL, &textW, &textH);
    SDL_Rect menu_text_rect2 = {5, 935, textW, textH};
    
    SDL_Surface* menu_text_surf3 = TTF_RenderText_Blended(font, "Project lead, design, programming: dev.as4", textColor_black);
    SDL_Texture* menu_text_txt3 = SDL_CreateTextureFromSurface(renderer, menu_text_surf3);
    SDL_FreeSurface(menu_text_surf3);
    SDL_QueryTexture(menu_text_txt3, NULL, NULL, &textW, &textH);
    SDL_Rect menu_text_rect3 = {5, 885, textW, textH};
    
    SDL_Surface* menu_text_surf4 = TTF_RenderText_Blended(font, "Button click sound: Universfield from Pixabay", textColor_black);
    SDL_Texture* menu_text_txt4 = SDL_CreateTextureFromSurface(renderer, menu_text_surf4);
    SDL_FreeSurface(menu_text_surf4);
    SDL_QueryTexture(menu_text_txt4, NULL, NULL, &textW, &textH);
    SDL_Rect menu_text_rect4 = {5, 855, textW, textH};
    
    SDL_Surface* menu_text_surf5 = TTF_RenderText_Blended(font, "Unageo font: Richard Sepsi", textColor_black);
    SDL_Texture* menu_text_txt5 = SDL_CreateTextureFromSurface(renderer, menu_text_surf5);
    SDL_FreeSurface(menu_text_surf5);
    SDL_QueryTexture(menu_text_txt5, NULL, NULL, &textW, &textH);
    SDL_Rect menu_text_rect5 = {5, 825, textW, textH};
    
    //new text
    SDL_Surface* textSurface3 = TTF_RenderText_Blended(font, "= Environment Variables =", textColor_black);
    SDL_Texture* textTexture3 = SDL_CreateTextureFromSurface(renderer, textSurface3);
    SDL_FreeSurface(textSurface3);
    SDL_QueryTexture(textTexture3, NULL, NULL, &textW, &textH);
    SDL_Rect textRect3 = {353, 50, textW, textH};
    SDL_Rect textRect3_1 = {353, 150, textW, textH};
    
    SDL_Surface* textSurface7 = TTF_RenderText_Blended(font, ">> = ", textColor_black);
    SDL_Texture* textTexture7 = SDL_CreateTextureFromSurface(renderer, textSurface7);
    SDL_FreeSurface(textSurface7);
    SDL_QueryTexture(textTexture7, NULL, NULL, &textW, &textH);
    SDL_Rect textRect7 = {72, 900, textW, textH};
    
    SDL_Surface* textSurface8 = TTF_RenderText_Blended(font, "You're writing the weight now... (kg)", textColor_black);
    SDL_Texture* textTexture8 = SDL_CreateTextureFromSurface(renderer, textSurface8);
    SDL_FreeSurface(textSurface8);
    SDL_QueryTexture(textTexture8, NULL, NULL, &textW, &textH);
    SDL_Rect textRect8 = {72, 870, textW, textH};
    
    SDL_Surface* textSurface9 = TTF_RenderText_Blended(font, "= Calculation results =", textColor_black);
    SDL_Texture* textTexture9 = SDL_CreateTextureFromSurface(renderer, textSurface9);
    SDL_FreeSurface(textSurface9);
    SDL_QueryTexture(textTexture9, NULL, NULL, &textW, &textH);
    SDL_Rect textRect9 = {375, 300, textW, textH};
    
    SDL_Surface* textSurface12 = TTF_RenderText_Blended(font, "You're writing the diameter now... (mm)", textColor_black);
    SDL_Texture* textTexture12 = SDL_CreateTextureFromSurface(renderer, textSurface12);
    SDL_FreeSurface(textSurface12);
    SDL_QueryTexture(textTexture12, NULL, NULL, &textW, &textH);
    SDL_Rect textRect12 = {72, 870, textW, textH};
    
    SDL_Surface* textSurface13 = TTF_RenderText_Blended(font, "You're writing the target now... (meters)", textColor_black);
    SDL_Texture* textTexture13 = SDL_CreateTextureFromSurface(renderer, textSurface13);
    SDL_FreeSurface(textSurface13);
    SDL_QueryTexture(textTexture13, NULL, NULL, &textW, &textH);
    SDL_Rect textRect13 = {72, 870, textW, textH};
    
    SDL_Surface* textSurface14 = TTF_RenderText_Blended(font, "You're writing the muzzle velocity now... (m/s)", textColor_black);
    SDL_Texture* textTexture14 = SDL_CreateTextureFromSurface(renderer, textSurface14);
    SDL_FreeSurface(textSurface14);
    SDL_QueryTexture(textTexture14, NULL, NULL, &textW, &textH);
    SDL_Rect textRect14 = {72, 870, textW, textH};
    
    SDL_Surface* e_variable_surf_1 = TTF_RenderText_Blended(font, "You're writing the error tolerance now... (meters)", textColor_black);
    SDL_Texture* e_variable_text_1 = SDL_CreateTextureFromSurface(renderer, e_variable_surf_1);
    SDL_FreeSurface(e_variable_surf_1);
    SDL_QueryTexture(e_variable_text_1, NULL, NULL, &textW, &textH);
    SDL_Rect e_variable_text_rect_1 = {72, 870, textW, textH};
    
    SDL_Surface* e_variable_surf_2 = TTF_RenderText_Blended(font, "You're writing the air temperature now... (celcius)", textColor_black);
    SDL_Texture* e_variable_text_2 = SDL_CreateTextureFromSurface(renderer, e_variable_surf_2);
    SDL_FreeSurface(e_variable_surf_2);
    SDL_QueryTexture(e_variable_text_2, NULL, NULL, &textW, &textH);
    SDL_Rect e_variable_text_rect_2 = {72, 870, textW, textH};
    
    SDL_Surface* e_variable_surf_3 = TTF_RenderText_Blended(font, "You're writing the air pressure now... (pascals)", textColor_black);
    SDL_Texture* e_variable_text_3 = SDL_CreateTextureFromSurface(renderer, e_variable_surf_3);
    SDL_FreeSurface(e_variable_surf_3);
    SDL_QueryTexture(e_variable_text_3, NULL, NULL, &textW, &textH);
    SDL_Rect e_variable_text_rect_3 = {72, 870, textW, textH};
    
    SDL_Surface* launch_angle_surf = TTF_RenderText_Blended(font, "You're writing the launch angle now... (0-89 degrees)", textColor_black);
    SDL_Texture* launch_angle_text = SDL_CreateTextureFromSurface(renderer, launch_angle_surf);
    SDL_FreeSurface(launch_angle_surf);
    SDL_QueryTexture(launch_angle_text, NULL, NULL, &textW, &textH);
    SDL_Rect launch_angle_rect = {72, 870, textW, textH};  
    
	std::string prevAirText;
	SDL_Texture* textTexture4 = nullptr;
	SDL_Rect textRect4 = {340, 100, 0, 0};
	SDL_Rect textRect4_1 = {340, 200, 0, 0};
	
	std::string prevTempText;
	SDL_Texture* textTexture5 = nullptr;
	SDL_Rect textRect5 = {350, 150, 0, 0};
	SDL_Rect textRect5_1 = {350, 250, 0, 0};
	
	std::string prevErrText;
	SDL_Texture* textTexture6 = nullptr;
	SDL_Rect textRect6 = {350, 200, 0, 0};
	SDL_Rect textRect6_1 = {350, 300, 0, 0};
	
	std::string prevBalText;
	SDL_Texture* textTexture10 = nullptr;
	SDL_Rect textRect10 = {355, 350, 0, 0};
	
	std::string prevBahText;
	SDL_Texture* textTexture11 = nullptr;
	SDL_Rect textRect11 = {355, 400, 0, 0};
	
	std::string prevLandText;
	SDL_Texture* land_text_texture = nullptr;
	SDL_Rect LandRect = {355, 350, 0, 0};
	
	std::string prevHeighttext;
	SDL_Texture* height_text_texture = nullptr;
	SDL_Rect HeightRect = {355, 400, 0, 0};
	
	std::string prevAirTimeText;
	SDL_Texture* airtime_text_texture = nullptr;
	SDL_Rect AirRect = {355, 450, 0, 0};
	
	std::cout << "✅ All text created successfully\n";
	
	std::cout << "✅ If you see this message, all modules/images/texts working without problem...\n";
   
	//MAIN LOOP
    while (running) {
		
		std::ostringstream Airstream;
		Airstream << std::fixed << std::setprecision(3) << air_pressure;
		std::string airText = Airstream.str() + " pascals air pressure.";

		if (airText != prevAirText) {
			prevAirText = airText;

			// Clean up old texture
			if (textTexture4) {
				SDL_DestroyTexture(textTexture4);
				textTexture4 = nullptr;
			}

			SDL_Surface* textSurface4 = TTF_RenderText_Blended(font, airText.c_str(), textColor_black);
			if (textSurface4) {
				textTexture4 = SDL_CreateTextureFromSurface(renderer, textSurface4);
				SDL_FreeSurface(textSurface4);

				SDL_QueryTexture(textTexture4, NULL, NULL, &textRect4.w, &textRect4.h);
				textRect4_1.w = textRect4.w;
				textRect4_1.h = textRect4.h;
			}
		}
		
		std::ostringstream Tempstream;
		Tempstream << std::fixed << std::setprecision(1) << temp_celcius;
		std::string tempText = Tempstream.str() + " celcius air temperature.";

		if (tempText != prevTempText) {
			prevTempText = tempText;

			// Clean up old texture
			if (textTexture5) {
				SDL_DestroyTexture(textTexture5);
				textTexture5 = nullptr;
			}

			SDL_Surface* textSurface5 = TTF_RenderText_Blended(font, tempText.c_str(), textColor_black);
			if (textSurface5) {
				textTexture5 = SDL_CreateTextureFromSurface(renderer, textSurface5);
				SDL_FreeSurface(textSurface5);

				SDL_QueryTexture(textTexture5, NULL, NULL, &textRect5.w, &textRect5.h);
				textRect5_1.w = textRect5.w;
				textRect5_1.h = textRect5.h;
			}
		}
		
		std::ostringstream Errorstream;
		Errorstream << std::fixed << std::setprecision(2) << error_tolerance;
		std::string errText = Errorstream.str() + " meters error tolerance.";

		if (errText != prevErrText) {
			prevErrText = errText;

			// Clean up old texture
			if (textTexture6) {
				SDL_DestroyTexture(textTexture6);
				textTexture6 = nullptr;
			}

			SDL_Surface* textSurface6 = TTF_RenderText_Blended(font, errText.c_str(), textColor_black);
			if (textSurface6) {
				textTexture6 = SDL_CreateTextureFromSurface(renderer, textSurface6);
				SDL_FreeSurface(textSurface6);

				SDL_QueryTexture(textTexture6, NULL, NULL, &textRect6.w, &textRect6.h);
				textRect6_1.w = textRect6.w;
				textRect6_1.h = textRect6.h;
			}
		}
		
		//SCREENS
		if (screens == "ARROW") {
					
			std::ostringstream Landstream;
			Landstream << std::fixed << std::setprecision(2) << landing_pos;
			std::string LandText = Landstream.str() + " meters away projectile landed.";

			if (LandText != prevLandText) {
				prevLandText = LandText;

				if (land_text_texture) {
					SDL_DestroyTexture(land_text_texture);
					land_text_texture = nullptr;
				}

				
				SDL_Surface* LandSurface = TTF_RenderText_Blended(font, LandText.c_str(), textColor_black);
					if (LandSurface) {
						land_text_texture = SDL_CreateTextureFromSurface(renderer, LandSurface);
						SDL_FreeSurface(LandSurface);

						SDL_QueryTexture(land_text_texture, NULL, NULL, &LandRect.w, &LandRect.h);
				}
			}
			
			std::ostringstream Heightstream;
			Heightstream << std::fixed << std::setprecision(2) << max_height_reach;
			std::string Heighttext = Heightstream.str() + " meters maximum altitude.";

			if (Heighttext != prevHeighttext) {
				prevHeighttext = Heighttext;

				if (height_text_texture) {
					SDL_DestroyTexture(height_text_texture);
					height_text_texture = nullptr;
				}

				
				SDL_Surface* HeightSurf = TTF_RenderText_Blended(font, Heighttext.c_str(), textColor_black);
					if (HeightSurf) {
						height_text_texture = SDL_CreateTextureFromSurface(renderer, HeightSurf);
						SDL_FreeSurface(HeightSurf);

						SDL_QueryTexture(height_text_texture, NULL, NULL, &HeightRect.w, &HeightRect.h);
				}
			}
			
			std::ostringstream AirTimeStream;
			AirTimeStream << std::fixed << std::setprecision(2) << total_time;
			std::string AirTimetext = AirTimeStream.str() + " seconds it spend on air.";

			if (AirTimetext != prevAirTimeText) {
				prevAirTimeText = AirTimetext;

				if (airtime_text_texture) {
					SDL_DestroyTexture(airtime_text_texture);
					airtime_text_texture = nullptr;
				}

				
				SDL_Surface* AirTextSurf = TTF_RenderText_Blended(font, AirTimetext.c_str(), textColor_black);
					if (AirTextSurf) {
						airtime_text_texture = SDL_CreateTextureFromSurface(renderer, AirTextSurf);
						SDL_FreeSurface(AirTextSurf);

						SDL_QueryTexture(airtime_text_texture, NULL, NULL, &AirRect.w, &AirRect.h);
				}
			}
			
			//EVENT HANDLER
			while (SDL_PollEvent(&event)) {
				if (event.type == SDL_QUIT) {
					sdl_quit();
					running = false;
				}
				if (event.type == SDL_MOUSEBUTTONDOWN) {
					SDL_Point mousePoint = { event.button.x, event.button.y };
					if (SDL_PointInRect(&mousePoint, &buttonRect13)) {
						Mix_PlayChannel(-1, buttonSound, 0);
						writing_variable = 1.0;
						current_variable = &velocity;
						//inputText = *current_variable; // load current value if you want
						typing = true;
						SDL_StartTextInput();
						std::cout << "Enter muzzle velocity of the projectile (m/s)" << std::endl;	
					}
					if (SDL_PointInRect(&mousePoint, &buttonRect12)) {
						Mix_PlayChannel(-1, buttonSound, 0);
						writing_variable = 2.0;
						current_variable = &launch_angle;
						//inputText = *current_variable; // load current value if you want
						typing = true;
						SDL_StartTextInput();
						std::cout << "Enter launch angle (degrees)" << std::endl;	
					}
					if (SDL_PointInRect(&mousePoint, &buttonRect11)) {
						Mix_PlayChannel(-1, buttonSound, 0);
						writing_variable = 3.0;
						current_variable = &diameter;
						//inputText = *current_variable; // load current value if you want
						typing = true;
						SDL_StartTextInput();
						std::cout << "Enter diameter of the projectile (mm)" << std::endl;	
					}
					if (SDL_PointInRect(&mousePoint, &buttonRect10)) {
						Mix_PlayChannel(-1, buttonSound, 0);
						writing_variable = 4.0;
						current_variable = &mass;
						//inputText = *current_variable; // load current value if you want
						typing = true;
						SDL_StartTextInput();
						std::cout << "Enter weight of the projectile (kg)" << std::endl;	
					}
					if (SDL_PointInRect(&mousePoint, &buttonRect14)) {
						Mix_PlayChannel(-1, buttonSound, 0);
						// Done typing
						writing_variable = 0.0;
						typing = false;
						SDL_StopTextInput();
						if (current_variable) {
							*current_variable = std::stod(inputText); // convert string to double
							//*current_variable = inputText;
							std::cout << "Saved as: " << *current_variable << std::endl;
						}
						current_variable = nullptr;
						inputText.clear();
					}
					if (SDL_PointInRect(&mousePoint, &buttonRect9)) {
						Mix_PlayChannel(-1, buttonSound, 0);
						calculate = true;
						error_handler = 0.0;

						if (velocity > 0 && launch_angle > 0 && diameter > 0 && mass > 0) {
							if (calculate == true) {
								
								//UNIT ARRANGEMENTS
								double temp_kelvin = temp_celcius + 273.15;
								
								//ENVIRONMENTAL EFFECTS
								const double R = 287.05; // gas constant for dry air
								double air_density = air_pressure / (R * temp_kelvin);
								const double gravity = 9.81; //generic earth gravity

							   //PROJECTILE CALCULATION
								const double radius = diameter / 2.0 / 1000.0;
								const double area = M_PI * radius * radius;
								const double drag_coefficient = 0.295; //generic for bullet-like shapes

								//LAST CALC.
								const double angle_rad = launch_angle * M_PI / 180.0;
								double vx = velocity * std::cos(angle_rad);
								double vy = velocity * std::sin(angle_rad);
								
								double x = 0.0;
								double y = 0.0;

								//TIME (SECONDS)
								const double dt = 0.01;
								
								//END USER INFO.
								double max_height = y;
								total_time = 0.0;

								 //SIM LOOP
								while (y >= 0.0) {
									double speed = std::sqrt(vx * vx + vy * vy);
									double drag_force = 0.5 * air_density * drag_coefficient * area * speed * speed;
									
									if (y > max_height) {
										max_height = y;
									}

									//DRAG EFFECT ON PROJECTILE
									double ax = -drag_force * (vx / speed) / mass;
									double ay = -drag_force * (vy / speed) / mass - gravity;

									//VELOCITY UPDATE
									vx += ax * dt;
									vy += ay * dt;

									//POSITION UPDATE
									x += vx * dt;
									y += vy * dt;
									
									total_time += dt;
									
									//x = projectile_landed;
								}
								
								//END USER INFO
								std::cout << " \n";
								std::cout << "Projectile landed " << x << " meters away from it's launch point.\n";
								std::cout << "Projectile reached maximum altitude of " << max_height << " meters.\n";
								std::cout << "Projectile spend " << total_time << " seconds from launch to landing.\n";
								landing_pos = x;
								max_height_reach = max_height;
								//std::cout << landing_pos;
								//std::cout << max_height_reach;
								
							calculate = false;
							}
						} else {
								std::cout << "Please enter all the information needed." << std::endl;
								error_handler = 1.0;
							}
					}
					
					if (SDL_PointInRect(&mousePoint, &buttonRect7)) {
						Mix_PlayChannel(-1, buttonSound, 0);
						screens = "MAIN_MENU";
						//std::cout << "mouse click inside rect1 at ("
						//		  << mousePoint.x << ", " << mousePoint.y << ")\n";
					}
				}
				if (event.type == SDL_TEXTINPUT && typing) {
					inputText += event.text.text;
				}
				if (event.type == SDL_KEYDOWN && typing) {
					if (event.key.keysym.sym == SDLK_BACKSPACE && !inputText.empty()) {
						inputText.pop_back();
					}
					else if (event.key.keysym.sym == SDLK_RETURN) {
						// Done typing
						writing_variable = 0.0;
						typing = false;
						SDL_StopTextInput();
						if (current_variable) {
							*current_variable = std::stod(inputText); // convert string to double
							//*current_variable = inputText;
							std::cout << "Saved as: " << *current_variable << std::endl;
						}
						current_variable = nullptr;
						inputText.clear();
					}
				}
			}
		
			
			//renderer start
			SDL_SetRenderDrawColor(renderer, 255, 255, 255, 255); // draw background
			SDL_RenderClear(renderer);
			
			SDL_SetRenderDrawColor(renderer, 0, 0, 255, 255);
			
			SDL_RenderCopy(renderer, main_menu, nullptr, &buttonRect7);
			SDL_RenderCopy(renderer, ew, nullptr, &buttonRect10);
			SDL_RenderCopy(renderer, et, nullptr, &buttonRect11);
			SDL_RenderCopy(renderer, e_launch_angle, nullptr, &buttonRect12);
			SDL_RenderCopy(renderer, emv, nullptr, &buttonRect13);
			SDL_RenderCopy(renderer, calculatee, nullptr, &buttonRect9);
			SDL_RenderCopy(renderer, enter_button, nullptr, &buttonRect14);
			
			if (error_handler == 1.0) {
				SDL_RenderCopy(renderer, warning1, nullptr, &buttonRect15);
			}
			
			
			SDL_RenderCopy(renderer, textTexture3, NULL, &textRect3);
			SDL_RenderCopy(renderer, textTexture4, NULL, &textRect4);
			SDL_RenderCopy(renderer, textTexture5, NULL, &textRect5);
			SDL_RenderCopy(renderer, textTexture6, NULL, &textRect6);
			SDL_RenderCopy(renderer, textTexture7, NULL, &textRect7);
			SDL_RenderCopy(renderer, textTexture9, NULL, &textRect9);
			SDL_RenderCopy(renderer, land_text_texture, NULL, &LandRect);
			SDL_RenderCopy(renderer, height_text_texture, NULL, &HeightRect);
			SDL_RenderCopy(renderer, airtime_text_texture, NULL, &AirRect);
			//SDL_RenderCopy(renderer, textTexture11, NULL, &textRect11);
			
			if (writing_variable == 1.0) {
				SDL_RenderCopy(renderer, textTexture14, NULL, &textRect14);
			}
			
			if (writing_variable == 2.0) {
				SDL_RenderCopy(renderer, launch_angle_text, NULL, &launch_angle_rect);
			}
			
			if (writing_variable == 3.0) {
				SDL_RenderCopy(renderer, textTexture12, NULL, &textRect12);
			}
			
			if (writing_variable == 4.0) {
				SDL_RenderCopy(renderer, textTexture8, NULL, &textRect8);
			}
			
			if (!inputText.empty()) {
				SDL_Surface* textSurface = TTF_RenderText_Blended(font, inputText.c_str(), textColor_black);
				SDL_Texture* textTexture = SDL_CreateTextureFromSurface(renderer, textSurface);
				SDL_Rect textRect = {130, 900, textSurface->w, textSurface->h};
				SDL_RenderCopy(renderer, textTexture, nullptr, &textRect);
				SDL_FreeSurface(textSurface);
				SDL_DestroyTexture(textTexture);
			}
			
			//renderer end
			SDL_RenderPresent(renderer);
		}
		if (screens == "LAUNCH_ANGLE") {
			
			std::ostringstream Balstream;
			Balstream << std::fixed << std::setprecision(5) << best_angle_low;
			std::string balText = Balstream.str() + " Lower trajectory";

			if (balText != prevBalText) {
				prevBalText = balText;

				// Clean up old texture
				if (textTexture10) {
					SDL_DestroyTexture(textTexture10);
					textTexture10 = nullptr;
				}

				SDL_Surface* textSurface10 = TTF_RenderText_Blended(font, balText.c_str(), textColor_black);
				if (textSurface10) {
					textTexture10 = SDL_CreateTextureFromSurface(renderer, textSurface10);
					SDL_FreeSurface(textSurface10);

					SDL_QueryTexture(textTexture10, NULL, NULL, &textRect10.w, &textRect10.h);
					//textRect6_1.w = textRect6.w;
					//textRect6_1.h = textRect6.h;
				}
			}
			
			std::ostringstream Bahstream;
			Bahstream << std::fixed << std::setprecision(5) << best_angle_high;
			std::string bahText = Bahstream.str() + " Higher trajectory";

			if (bahText != prevBahText) {
				prevBahText = bahText;

				// Clean up old texture
				if (textTexture11) {
					SDL_DestroyTexture(textTexture11);
					textTexture11 = nullptr;
				}

				SDL_Surface* textSurface11 = TTF_RenderText_Blended(font, bahText.c_str(), textColor_black);
				if (textSurface11) {
					textTexture11 = SDL_CreateTextureFromSurface(renderer, textSurface11);
					SDL_FreeSurface(textSurface11);

					SDL_QueryTexture(textTexture11, NULL, NULL, &textRect11.w, &textRect11.h);
					//textRect6_1.w = textRect6.w;
					//textRect6_1.h = textRect6.h;
				}
			}
			
			//EVENT HANDLER
			while (SDL_PollEvent(&event)) {
				if (event.type == SDL_QUIT) {
					sdl_quit();
					running = false;
				}
				if (event.type == SDL_MOUSEBUTTONDOWN) {
					SDL_Point mousePoint = { event.button.x, event.button.y };
					if (SDL_PointInRect(&mousePoint, &buttonRect13)) {
						Mix_PlayChannel(-1, buttonSound, 0);
						writing_variable = 1.0;
						current_variable = &velocity;
						//inputText = *current_variable; // load current value if you want
						typing = true;
						SDL_StartTextInput();
						std::cout << "Enter muzzle velocity of the projectile (m/s)" << std::endl;	
					}
					if (SDL_PointInRect(&mousePoint, &buttonRect12)) {
						Mix_PlayChannel(-1, buttonSound, 0);
						writing_variable = 2.0;
						current_variable = &target;
						//inputText = *current_variable; // load current value if you want
						typing = true;
						SDL_StartTextInput();
						std::cout << "Enter how far target away (meters)" << std::endl;	
					}
					if (SDL_PointInRect(&mousePoint, &buttonRect11)) {
						Mix_PlayChannel(-1, buttonSound, 0);
						writing_variable = 3.0;
						current_variable = &diameter;
						//inputText = *current_variable; // load current value if you want
						typing = true;
						SDL_StartTextInput();
						std::cout << "Enter diameter of the projectile (mm)" << std::endl;	
					}
					if (SDL_PointInRect(&mousePoint, &buttonRect10)) {
						Mix_PlayChannel(-1, buttonSound, 0);
						writing_variable = 4.0;
						current_variable = &mass;
						//inputText = *current_variable; // load current value if you want
						typing = true;
						SDL_StartTextInput();
						std::cout << "Enter weight of the projectile (kg)" << std::endl;	
					}
					if (SDL_PointInRect(&mousePoint, &buttonRect14)) {
						Mix_PlayChannel(-1, buttonSound, 0);
						// Done typing
						writing_variable = 0.0;
						typing = false;
						SDL_StopTextInput();
						if (current_variable) {
							*current_variable = std::stod(inputText); // convert string to double
							//*current_variable = inputText;
							std::cout << "Saved as: " << *current_variable << std::endl;
						}
						current_variable = nullptr;
						inputText.clear();
					}
					if (SDL_PointInRect(&mousePoint, &buttonRect9)) {
						Mix_PlayChannel(-1, buttonSound, 0);
						calculate = true;
						error_handler = 0.0;
						
						if (velocity > 0 && target > 0 && diameter > 0 && mass > 0) {
							if (calculate == true) {
								double temp_kelvin = temp_celcius + 273.15;
		
								//ENVIRONMENTAL EFFECTS
								const double R = 287.057; //DEAFULT GAS CONSTANT FOR DRY AIR
								double air_density = air_pressure / (R * temp_kelvin);
								const double gravity = 9.807; //GENERIC EARTH GRAVITY

								//PROJECTILE CALCULATION
								double radius = diameter / 2.0 / 1000.0;
								double area = M_PI * radius * radius;
								double drag_coefficient = 0.295; //generic for bullet-like shapes
								
								//TIME (SECONDS)
								double dt = 0.01;

								//SIMULATION
								for (double angle_deg = 1.0; angle_deg <= 89.0; angle_deg += 0.01) {
									//CONVERT ANGLE TO RADIANS
									double angle_rad = angle_deg * M_PI / 180.0;

									//START POSITION AND VELOCITY
									double x = 0.0;
									double y = 0.0;
									double vx = cos(angle_rad) * velocity;
									double vy = sin(angle_rad) * velocity;

									//SHELL SIM
									while (y >= 0.0) {
										//SPEED CALC.
										double speed = std::sqrt(vx * vx + vy * vy);

										//DRAG FORCE CALC.
										double drag_force = 0.5 * air_density * drag_coefficient * area * speed * speed;

										//CALC. ACCELERATION FROM DRAG
										double ax = -drag_force * (vx / speed) / mass;
										double ay = -gravity - (drag_force * (vy / speed) / mass);

										//VELOCITY UPDATE
										vx += ax * dt;
										vy += ay * dt;

										//POSITION UPDATE
										x += vx * dt;
										y += vy * dt;
									}
									
									double error = std::abs(x - target);
									
									if (error <= error_tolerance) {
										if (best_angle_low == 0.0) {
											best_angle_low = angle_deg;
											best_error_low = error;
										}
										best_angle_high = angle_deg;
										best_error_high = error;
									}
								}
								
								
								std::cout << std::fixed << std::setprecision(5) << "\n";
								if (best_error_high > 10 && best_error_low > 10) {
									std::cout << "! Your projectile can't reach to target without MAJOR errors.\n";
									std::cout << "Your projectile either too slow or too fast.\n";
									error_handler = 2.0;
								}
								else if (best_angle_high == best_angle_low) {
									std::cout << "For send your projectile to the target " << target << " meters away,\n";
									std::cout << "You have one launch angle:\n";
									std::cout << "\n";
									std::cout << best_angle_low << " degrees with " << best_error_low << " meters error.\n";	
								}
								else {
									std::cout << "For send your projectile to the target " << target << " meters away,\n";
									std::cout << "You have two launch angles:\n";
									std::cout << "\n";
									std::cout << "Lower trajectory, shorter air time:\n";
									std::cout << best_angle_low << " degrees with " << best_error_low << " meters error.\n";
									std::cout << "Higher trajectory, longer air time:\n";
									std::cout << best_angle_high << " degrees with " << best_error_high << " meters error.\n";	
									
								}
							calculate = false;
							}
						} else {
								std::cout << "Please enter all the information needed." << std::endl;
								error_handler = 1.0;
							}
					}
					
					if (SDL_PointInRect(&mousePoint, &buttonRect7)) {
						Mix_PlayChannel(-1, buttonSound, 0);
						screens = "MAIN_MENU";
						//std::cout << "mouse click inside rect1 at ("
						//		  << mousePoint.x << ", " << mousePoint.y << ")\n";
					}
				}
				if (event.type == SDL_TEXTINPUT && typing) {
					inputText += event.text.text;
				}
				if (event.type == SDL_KEYDOWN && typing) {
					if (event.key.keysym.sym == SDLK_BACKSPACE && !inputText.empty()) {
						inputText.pop_back();
					}
					else if (event.key.keysym.sym == SDLK_RETURN) {
						// Done typing
						writing_variable = 0.0;
						typing = false;
						SDL_StopTextInput();
						if (current_variable) {
							*current_variable = std::stod(inputText); // convert string to double
							//*current_variable = inputText;
							std::cout << "Saved as: " << *current_variable << std::endl;
						}
						current_variable = nullptr;
						inputText.clear();
					}
				}
			}
		
			
			//renderer start
			SDL_SetRenderDrawColor(renderer, 255, 255, 255, 255); // draw background
			SDL_RenderClear(renderer);
			
			SDL_SetRenderDrawColor(renderer, 0, 0, 255, 255);
			
			SDL_RenderCopy(renderer, main_menu, nullptr, &buttonRect7);
			SDL_RenderCopy(renderer, ew, nullptr, &buttonRect10);
			SDL_RenderCopy(renderer, et, nullptr, &buttonRect11);
			SDL_RenderCopy(renderer, ehfta, nullptr, &buttonRect12);
			SDL_RenderCopy(renderer, emv, nullptr, &buttonRect13);
			SDL_RenderCopy(renderer, calculatee, nullptr, &buttonRect9);
			SDL_RenderCopy(renderer, enter_button, nullptr, &buttonRect14);
			
			if (error_handler == 1.0) {
				SDL_RenderCopy(renderer, warning1, nullptr, &buttonRect15);
			}
			
			if (error_handler == 2.0) {
				SDL_RenderCopy(renderer, warning, nullptr, &buttonRect15);
			}
			
			
			SDL_RenderCopy(renderer, textTexture3, NULL, &textRect3);
			SDL_RenderCopy(renderer, textTexture4, NULL, &textRect4);
			SDL_RenderCopy(renderer, textTexture5, NULL, &textRect5);
			SDL_RenderCopy(renderer, textTexture6, NULL, &textRect6);
			SDL_RenderCopy(renderer, textTexture7, NULL, &textRect7);
			SDL_RenderCopy(renderer, textTexture9, NULL, &textRect9);
			SDL_RenderCopy(renderer, textTexture10, NULL, &textRect10);
			SDL_RenderCopy(renderer, textTexture11, NULL, &textRect11);
			
			if (writing_variable == 1.0) {
				SDL_RenderCopy(renderer, textTexture14, NULL, &textRect14);
			}
			
			if (writing_variable == 2.0) {
				SDL_RenderCopy(renderer, textTexture13, NULL, &textRect13);
			}
			
			if (writing_variable == 3.0) {
				SDL_RenderCopy(renderer, textTexture12, NULL, &textRect12);
			}
			
			if (writing_variable == 4.0) {
				SDL_RenderCopy(renderer, textTexture8, NULL, &textRect8);
			}
			
			if (!inputText.empty()) {
				SDL_Surface* textSurface = TTF_RenderText_Blended(font, inputText.c_str(), textColor_black);
				SDL_Texture* textTexture = SDL_CreateTextureFromSurface(renderer, textSurface);
				SDL_Rect textRect = {130, 900, textSurface->w, textSurface->h};
				SDL_RenderCopy(renderer, textTexture, nullptr, &textRect);
				SDL_FreeSurface(textSurface);
				SDL_DestroyTexture(textTexture);
			}
			
			//renderer end
			SDL_RenderPresent(renderer);
			
		}
		if (screens == "CHANGE_E_VARIABLES") {
			
			//EVENT HANDLER
			while (SDL_PollEvent(&event)) {
				SDL_Point mousePoint = { event.button.x, event.button.y };
				if (event.type == SDL_QUIT) {
					sdl_quit();
					running = false;
				}
				if (event.type == SDL_MOUSEBUTTONDOWN) {
					
					if (SDL_PointInRect(&mousePoint, &buttonRect7)) {
						Mix_PlayChannel(-1, buttonSound, 0);
						screens = "MAIN_MENU";
						//std::cout << "mouse click inside rect1 at ("
						//		  << mousePoint.x << ", " << mousePoint.y << ")\n";
					}
					
					if (SDL_PointInRect(&mousePoint, &cerrort_button_rect)) {
						Mix_PlayChannel(-1, buttonSound, 0);
						writing_variable = 5.0;
						current_variable = &error_tolerance;
						//inputText = *current_variable; // load current value if you want
						typing = true;
						SDL_StartTextInput();
						std::cout << "Enter error tolerance (meters)" << std::endl;	
					}
					if (SDL_PointInRect(&mousePoint, &cairt_button_rect)) {
						Mix_PlayChannel(-1, buttonSound, 0);
						writing_variable = 6.0;
						current_variable = &temp_celcius;
						//inputText = *current_variable; // load current value if you want
						typing = true;
						SDL_StartTextInput();
						std::cout << "Enter air temperature (celcius)" << std::endl;	
					}
					if (SDL_PointInRect(&mousePoint, &cairp_button_rect)) {
						Mix_PlayChannel(-1, buttonSound, 0);
						writing_variable = 7.0;
						current_variable = &air_pressure;
						//inputText = *current_variable; // load current value if you want
						typing = true;
						SDL_StartTextInput();
						std::cout << "Enter air pressure (pascals)" << std::endl;	
					}
					
					if (SDL_PointInRect(&mousePoint, &enter_button_1_rect)) {
						Mix_PlayChannel(-1, buttonSound, 0);
						// Done typing
						typing = false;
						SDL_StopTextInput();
						if (current_variable) {
							*current_variable = std::stod(inputText); // convert string to double
							//*current_variable = inputText;
							std::cout << "Saved as: " << *current_variable << std::endl;
						}
						current_variable = nullptr;
						inputText.clear();
					}
				}
				if (event.type == SDL_TEXTINPUT && typing) {
					inputText += event.text.text;
				}
				if (event.type == SDL_KEYDOWN && typing) {
					if (event.key.keysym.sym == SDLK_BACKSPACE && !inputText.empty()) {
						inputText.pop_back();
					}
					else if (event.key.keysym.sym == SDLK_RETURN) {
						// Done typing
						writing_variable = 0.0;
						typing = false;
						SDL_StopTextInput();
						if (current_variable) {
							*current_variable = std::stod(inputText); // convert string to double
							//*current_variable = inputText;
							std::cout << "Saved as: " << *current_variable << std::endl;
						}
						current_variable = nullptr;
						inputText.clear();
					}
				}
			}
		
			
			//renderer start
			SDL_SetRenderDrawColor(renderer, 255, 255, 255, 255); // draw background
			SDL_RenderClear(renderer);
			
			SDL_SetRenderDrawColor(renderer, 0, 0, 255, 255);
			
			SDL_RenderCopy(renderer, main_menu, nullptr, &buttonRect7);
			SDL_RenderCopy(renderer, c_air_pressure, nullptr, &cairp_button_rect);
			SDL_RenderCopy(renderer, c_air_temperature, nullptr, &cairt_button_rect);
			SDL_RenderCopy(renderer, c_error_tolerance, nullptr, &cerrort_button_rect);
			SDL_RenderCopy(renderer, enter_button, nullptr, &enter_button_1_rect);
			
			SDL_RenderCopy(renderer, textTexture3, NULL, &textRect3_1);
			SDL_RenderCopy(renderer, textTexture4, NULL, &textRect4_1);
			SDL_RenderCopy(renderer, textTexture5, NULL, &textRect5_1);
			SDL_RenderCopy(renderer, textTexture6, NULL, &textRect6_1);
			SDL_RenderCopy(renderer, textTexture7, NULL, &textRect7);
			
			if (writing_variable == 5.0) {
				SDL_RenderCopy(renderer, e_variable_text_1, NULL, &e_variable_text_rect_1);
			}
			
			if (writing_variable == 6.0) {
				SDL_RenderCopy(renderer, e_variable_text_2, NULL, &e_variable_text_rect_2);
			}
			
			if (writing_variable == 7.0) {
				SDL_RenderCopy(renderer, e_variable_text_3, NULL, &e_variable_text_rect_3);
			}
			
			if (!inputText.empty()) {
				SDL_Surface* textSurface = TTF_RenderText_Blended(font, inputText.c_str(), textColor_black);
				SDL_Texture* textTexture = SDL_CreateTextureFromSurface(renderer, textSurface);
				SDL_Rect textRect = {130, 900, textSurface->w, textSurface->h};
				SDL_RenderCopy(renderer, textTexture, nullptr, &textRect);
				SDL_FreeSurface(textSurface);
				SDL_DestroyTexture(textTexture);
			}
			
			//renderer end
			SDL_RenderPresent(renderer);
			
		}
		if (screens == "MAIN_MENU") {
			//EVENT HANDLER
			while (SDL_PollEvent(&event)) {
				if (event.type == SDL_QUIT) {
					sdl_quit();
					running = false;
				}
				
				if (event.type == SDL_MOUSEBUTTONDOWN) {
					SDL_Point mousePoint = { event.button.x, event.button.y };
					//launch angle calculator button
					if (SDL_PointInRect(&mousePoint, &menu_button_1_rect)) {
						Mix_PlayChannel(-1, buttonSound, 0);
						screens = "LAUNCH_ANGLE";
						//std::cout << "mouse click inside rect1 at ("
						//		  << mousePoint.x << ", " << mousePoint.y << ")\n";
						
						}
					//arrow-like shot button
					if (SDL_PointInRect(&mousePoint, &menu_button_2_rect)) {
						Mix_PlayChannel(-1, buttonSound, 0);
						screens = "ARROW";
						//std::cout << "mouse click inside rect2 at ("
						//		  << mousePoint.x << ", " << mousePoint.y << ")\n";
						
						}
					//rocket-like shot button
					if (SDL_PointInRect(&mousePoint, &menu_button_3_rect)) {
						//std::cout << "mouse click inside rect3 at ("
						//		  << mousePoint.x << ", " << mousePoint.y << ")\n";
						
						}
					//change e. variables button
					if (SDL_PointInRect(&mousePoint, &menu_button_4_rect)) {
						Mix_PlayChannel(-1, buttonSound, 0);
						screens = "CHANGE_E_VARIABLES";
						//std::cout << "mouse click inside rect4 at ("
						//		  << mousePoint.x << ", " << mousePoint.y << ")\n";
						
						}
					//exit button
					if (SDL_PointInRect(&mousePoint, &menu_button_5_rect)) {
						//std::cout << "mouse click inside rect5 at ("
						//		  << mousePoint.x << ", " << mousePoint.y << ")\n";
						running = false;
						
						}
					//explanation button
					if (SDL_PointInRect(&mousePoint, &menu_button_6_rect)) {
						Mix_PlayChannel(-1, buttonSound, 0);
						//std::cout << "mouse click inside rect6 at ("
						//		  << mousePoint.x << ", " << mousePoint.y << ")\n";
						if (show_info == false) {
							show_info = true;
						}
						else {
							show_info = false;
						}
					}
					if (SDL_PointInRect(&mousePoint, &info_rect)) {
						//std::cout << "mouse click inside rect8 at ("
						//		  << mousePoint.x << ", " << mousePoint.y << ")\n";
						if (show_info == true) {
							show_info = false;
							Mix_PlayChannel(-1, buttonSound, 0);
						}
					}
				}
			}

			//RENDERER START
			SDL_SetRenderDrawColor(renderer, 255, 255, 255, 255); // draw background
			SDL_RenderClear(renderer);

			SDL_RenderCopy(renderer, ILE_logo, nullptr, &ILE_logo_rect);
			
			SDL_RenderCopy(renderer, launch_angle_calc_button, nullptr, &menu_button_1_rect);
			SDL_RenderCopy(renderer, ashot_arrow, nullptr, &menu_button_2_rect);
			SDL_RenderCopy(renderer, ashot_rocket, nullptr, &menu_button_3_rect);
			SDL_RenderCopy(renderer, change_e_variable_button, nullptr, &menu_button_4_rect);
			SDL_RenderCopy(renderer, exit_button, nullptr, &menu_button_5_rect);
			SDL_RenderCopy(renderer, info_button, nullptr, &menu_button_6_rect);
			
			if (show_info == true) {
				SDL_RenderCopy(renderer, info, nullptr, &info_rect);
			}	
			
			SDL_RenderCopy(renderer, menu_text_txt1, NULL, &menu_text_rect1);
			SDL_RenderCopy(renderer, menu_text_txt2, NULL, &menu_text_rect2);
			SDL_RenderCopy(renderer, menu_text_txt3, NULL, &menu_text_rect3);
			SDL_RenderCopy(renderer, menu_text_txt4, NULL, &menu_text_rect4);
			SDL_RenderCopy(renderer, menu_text_txt5, NULL, &menu_text_rect5);

			SDL_RenderPresent(renderer);
		}
	}
	
	sdl_quit();
	running = false;
}
